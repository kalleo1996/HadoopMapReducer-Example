package firstHadoop;

public class covidvaccinemaxforCountry {

}
