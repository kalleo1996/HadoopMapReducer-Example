package firstHadoop;

public class PartitionerMy {

}
