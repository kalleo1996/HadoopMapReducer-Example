package firstHadoop;

import java.io.File;
import java.io.IOException;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import firstHadoop.topten.TopTenMapper;
import firstHadoop.topten.TopTenReducer;

public class assignmentVideo {

	public static class MapClass extends Mapper<Object, Text, Text, Text> {
		
		public void map(Object key, Text value, Context context) {
		try {
		String[] str = value.toString().split(",");
		
		String gener = str[3]; 
		String noOfVaccine=str[0]+","+str[2]+","+str[3];
		
		
		context.write(new Text(gener), new Text(noOfVaccine));
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}
		
		}
		}	
	
	
	
	
	
	
	
	
}
